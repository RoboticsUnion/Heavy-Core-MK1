#include "serial-conection.hpp" 
#include "../../../ansi_color_chart/ansi_color_chart.hpp"

#include "../../../Terminal/Terminal-OUT/Terminal-OUT.hpp"
#include "../../../Terminal/Terminal-IN/Terminal-IN.hpp"

#include <iostream>
#include <windows.h>
# include <vector>

#include <setupapi.h>
#include <initguid.h>
#include <ntddser.h>

#pragma comment(lib, "Setupapi.lib")
#pragma comment(lib, "Advapi32.lib")

using namespace std;

Serial serial;

string Serial::serial_conect_GUI(string PORT_GUI, int baudrate_GUI) {

    terminal_out.terminal_custom_output("Trying to connect to: " + PORT_GUI + " with BAUD: " + to_string(baudrate_GUI), ansi_color_chart::yellow);

    
    // fuses the Port_gui with "\\\\.\\"
    string portName = "\\\\.\\" + PORT_GUI;

    // creates a handle for the PORT rules/conduct
    HANDLE hSerial = CreateFileA(
        portName.c_str(),
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL
    );
    // if the handle value is invalid the system will report it
    if (hSerial == INVALID_HANDLE_VALUE) {
        
        string error = terminal_out.terminal_error_output("error_opening_port_GUI");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_opening_port_GUI";
    }
    // start a dcb for configuring baudrates
    DCB dcbSerialParams = { 0 };
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    // error handeling for dcb
    if (!GetCommState(hSerial, &dcbSerialParams)) {
        CloseHandle(hSerial);
        
        string error = terminal_out.terminal_error_output("error_reading_setting_GUI");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_reading_setting_GUI";
    }
    // dcb configuring
    dcbSerialParams.BaudRate = baudrate_GUI;
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;
    // error set atributes
    if (!SetCommState(hSerial, &dcbSerialParams)) {
        CloseHandle(hSerial);
        
        string error = terminal_out.terminal_error_output("error_set_conection_atributs_GUI");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_set_conection_atributs_GUI";
    }
    // timeout configuration
    COMMTIMEOUTS timeouts = {0};
    timeouts.ReadIntervalTimeout = 50;
    timeouts.ReadTotalTimeoutConstant = 50;
    timeouts.ReadTotalTimeoutMultiplier = 10;
    timeouts.WriteTotalTimeoutConstant = 50;
    timeouts.WriteTotalTimeoutMultiplier = 10;
    SetCommTimeouts(hSerial, &timeouts);
    // stores handle for later use
    this->m_hSerialGUI = hSerial; // Store the handle for later use

    terminal_out.terminal_custom_output("Connection was successful!", ansi_color_chart::green);

    return "Connection was successful!";
}

void Serial::disconnect_serial_GUI() {
    // closing conection
    if (m_hSerialGUI != INVALID_HANDLE_VALUE) {
        CloseHandle(this->m_hSerialGUI);
        this->m_hSerialGUI = INVALID_HANDLE_VALUE;
        terminal_out.terminal_custom_output("Gui Port disconected", ansi_color_chart::green);

    }
}

string Serial::serial_conect_CON1(string PORT_CON1, int baudrate_CON1) {

    terminal_out.terminal_custom_output("Trying to connect to: " + PORT_CON1 + " with BAUD: " + to_string(baudrate_CON1), ansi_color_chart::yellow);
    
    // fuses the Port_gui with "\\\\.\\"
    string portName = "\\\\.\\" + PORT_CON1;

    // creates a handle for the PORT rules/conduct
    HANDLE hSerial = CreateFileA(
        portName.c_str(),
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL
    );
    // if the handle value is invalid the system will report it
    if (hSerial == INVALID_HANDLE_VALUE) {
        
        string error = terminal_out.terminal_error_output("error_opening_port_CON1");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_opening_port_CON1";
    }
    // start a dcb for configuring baudrates
    DCB dcbSerialParams = { 0 };
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    // error handeling for dcb
    if (!GetCommState(hSerial, &dcbSerialParams)) {
        CloseHandle(hSerial);
        
        string error = terminal_out.terminal_error_output("error_reading_setting_CON1");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_reading_setting_CON1";
    }
    // dcb configuring
    dcbSerialParams.BaudRate = baudrate_CON1;
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;
    // error set atributes
    if (!SetCommState(hSerial, &dcbSerialParams)) {
        CloseHandle(hSerial);
        
        string error = terminal_out.terminal_error_output("error_set_conection_atributs_CON1");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_set_conection_atributs_CON1";
    }
    // timeout configuration
    COMMTIMEOUTS timeouts = {0};
    timeouts.ReadIntervalTimeout = 50;
    timeouts.ReadTotalTimeoutConstant = 50;
    timeouts.ReadTotalTimeoutMultiplier = 10;
    timeouts.WriteTotalTimeoutConstant = 50;
    timeouts.WriteTotalTimeoutMultiplier = 10;
    SetCommTimeouts(hSerial, &timeouts);
    // stores handle for later use
    this->m_hSerialCON1 = hSerial; // Store the handle for later use

    terminal_out.terminal_custom_output("Connection was successful!", ansi_color_chart::green);

    return "Connection was successful!";
}

void Serial::disconnect_serial_CON1() {
    // closing conection
    if (m_hSerialCON1 != INVALID_HANDLE_VALUE) {
        CloseHandle(this->m_hSerialCON1);
        this->m_hSerialCON1 = INVALID_HANDLE_VALUE;
        terminal_out.terminal_custom_output("CON1 Port disconected", ansi_color_chart::green);

    }
}

string Serial::serial_conect_CON2(string PORT_CON2, int baudrate_CON2) {

    terminal_out.terminal_custom_output("Trying to connect to: " + PORT_CON2 + " with BAUD: " + to_string(baudrate_CON2), ansi_color_chart::yellow);
    
    // fuses the Port_con2 with "\\\\.\\"
    string portName = "\\\\.\\" + PORT_CON2;

    // creates a handle for the PORT rules/conduct
    HANDLE hSerial = CreateFileA(
        portName.c_str(),
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING, 
        FILE_ATTRIBUTE_NORMAL, 
        NULL
    );
    // if the handle value is invalid the system will report it
    if (hSerial == INVALID_HANDLE_VALUE) {
        
        string error = terminal_out.terminal_error_output("error_opening_port_CON2");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_opening_port_CON2";
    }
    // start a dcb for configuring baudrates
    DCB dcbSerialParams = { 0 };
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    // error handeling for dcb
    if (!GetCommState(hSerial, &dcbSerialParams)) {
        CloseHandle(hSerial);
        
        string error = terminal_out.terminal_error_output("error_reading_setting_CON2");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_reading_setting_CON2";
    }
    // dcb configuring
    dcbSerialParams.BaudRate = baudrate_CON2;
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;
    // error set atributes
    if (!SetCommState(hSerial, &dcbSerialParams)) {
        CloseHandle(hSerial);
        
        string error = terminal_out.terminal_error_output("error_set_conection_atributs_CON2");
        terminal_out.terminal_custom_output(error, ansi_color_chart::yellow);
        return "error_set_conection_atributs_CON2";
    }
    // timeout configuration
    COMMTIMEOUTS timeouts = {0};
    timeouts.ReadIntervalTimeout = 50;
    timeouts.ReadTotalTimeoutConstant = 50;
    timeouts.ReadTotalTimeoutMultiplier = 10;
    timeouts.WriteTotalTimeoutConstant = 50;
    timeouts.WriteTotalTimeoutMultiplier = 10;
    SetCommTimeouts(hSerial, &timeouts);
    // stores handle for later use
    this->m_hSerialCON2 = hSerial; // Store the handle for later use

    terminal_out.terminal_custom_output("Connection was successful!", ansi_color_chart::green);

    return "Connection was successful!";
}

void Serial::disconnect_serial_CON2() {
    // closing conection
    if (m_hSerialCON2 != INVALID_HANDLE_VALUE) {
        CloseHandle(this->m_hSerialCON2);
        this->m_hSerialCON2 = INVALID_HANDLE_VALUE;
        terminal_out.terminal_custom_output("CON2 Port disconected", ansi_color_chart::green);

    }
}

vector<string> Serial::check_serial_available(string PORT_GUI, int baudrate_GUI, string PORT_CON1, int baudrate_CON1, string PORT_CON2, int baudrate_CON2) {

    terminal_out.terminal_custom_output("Checking conection status to Serial GUI, CON1 and CON2", ansi_color_chart::bright_blue);
    DWORD errors;
    COMSTAT status;
    string error_output;

    vector<string> return_handle = {"GUI-OK", "CON1-OK", "CON2-OK"};
    bool any_error = false;

    if(!ClearCommError(this->m_hSerialGUI, &errors, &status)) {  // Check if the serial GUI port is available
        CloseHandle(this->m_hSerialGUI);
        this->m_hSerialGUI = INVALID_HANDLE_VALUE;
        return_handle[0] = "GUI-NOT-CONECTED";
        any_error = true;
        error_output = terminal_out.terminal_error_output("warning_GUI_ser_disc");  
        terminal_out.terminal_custom_output(error_output, ansi_color_chart::red);
    }

    if(!ClearCommError(this->m_hSerialCON1, &errors, &status)) {  // Check if the serial CON1 port is available
        CloseHandle(this->m_hSerialCON1);
        this->m_hSerialCON1 = INVALID_HANDLE_VALUE;
        return_handle[1] = "CON1-NOT-CONECTED";
        any_error = true;
        error_output = terminal_out.terminal_error_output("warning_CON1_ser_disc");  
        terminal_out.terminal_custom_output(error_output, ansi_color_chart::red);
    }

    if(!ClearCommError(this->m_hSerialCON2, &errors, &status)) {  // Check if the serial CON2 port is available
        CloseHandle(this->m_hSerialCON2);
        this->m_hSerialCON2 = INVALID_HANDLE_VALUE;
        return_handle[2] = "CON2-NOT-CONECTED";
        any_error = true;
        error_output = terminal_out.terminal_error_output("warning_CON2_ser_disc");  
        terminal_out.terminal_custom_output(error_output, ansi_color_chart::red);
    }

    if(!any_error) {  // All serial ports are connected
        terminal_out.terminal_custom_output("All Serial Ports are connected", ansi_color_chart::green);
    } else {
        terminal_out.terminal_custom_output("Some serial Ports are disconnected", ansi_color_chart::red);
    }

    return return_handle;
    
}

vector<string> Serial::search_for_serial_ports() { //AI SHIT FUCKING WINDOWS API SHIT FUCKING HELL

    this->availablePorts.clear();

    // Get all currently present COM port device interfaces
    HDEVINFO deviceInfoSet = SetupDiGetClassDevsW(
        &GUID_DEVINTERFACE_COMPORT,
        nullptr,
        nullptr,
        DIGCF_PRESENT | DIGCF_DEVICEINTERFACE
    );

    if (deviceInfoSet == INVALID_HANDLE_VALUE) {
        return this->availablePorts;
    }

    // Enumerate all COM port interfaces
    for (DWORD deviceIndex = 0; ; deviceIndex++) {

        SP_DEVICE_INTERFACE_DATA interfaceData{};
        interfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

        if (!SetupDiEnumDeviceInterfaces(
            deviceInfoSet,
            nullptr,
            &GUID_DEVINTERFACE_COMPORT,
            deviceIndex,
            &interfaceData
        )) {

            if (GetLastError() == ERROR_NO_MORE_ITEMS) {
                break;
            }

            break;
        }

        // Get the required buffer size
        DWORD requiredSize = 0;

        SetupDiGetDeviceInterfaceDetailW(
            deviceInfoSet,
            &interfaceData,
            nullptr,
            0,
            &requiredSize,
            nullptr
        );

        if (GetLastError() != ERROR_INSUFFICIENT_BUFFER ||
            requiredSize == 0) {
            continue;
        }

        // Allocate the required buffer
        vector<BYTE> detailBuffer(requiredSize);

        PSP_DEVICE_INTERFACE_DETAIL_DATA_W detailData =
            reinterpret_cast<PSP_DEVICE_INTERFACE_DETAIL_DATA_W>(
                detailBuffer.data()
            );

        detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_W);

        SP_DEVINFO_DATA deviceInfoData{};
        deviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

        // Get device information
        if (!SetupDiGetDeviceInterfaceDetailW(
            deviceInfoSet,
            &interfaceData,
            detailData,
            requiredSize,
            nullptr,
            &deviceInfoData
        )) {
            continue;
        }

        // Open the device registry key
        HKEY deviceKey = SetupDiOpenDevRegKey(
            deviceInfoSet,
            &deviceInfoData,
            DICS_FLAG_GLOBAL,
            0,
            DIREG_DEV,
            KEY_QUERY_VALUE
        );

        if (deviceKey == INVALID_HANDLE_VALUE) {
            continue;
        }

        // Read the actual COM port name
        wchar_t portBuffer[256]{};

        DWORD portType = 0;
        DWORD portBufferSize = sizeof(portBuffer);

        LONG registryResult = RegQueryValueExW(
            deviceKey,
            L"PortName",
            nullptr,
            &portType,
            reinterpret_cast<LPBYTE>(portBuffer),
            &portBufferSize
        );

        RegCloseKey(deviceKey);

        portBuffer[255] = L'\0';

        if (registryResult != ERROR_SUCCESS ||
            (portType != REG_SZ && portType != REG_EXPAND_SZ)) {
            continue;
        }

        wstring widePortName(portBuffer);

        // Only accept actual COM port names
        if (widePortName.rfind(L"COM", 0) != 0) {
            continue;
        }

        // Get the device friendly name for identification
        wchar_t deviceNameBuffer[512]{};

        DWORD nameType = 0;

        if (!SetupDiGetDeviceRegistryPropertyW(
            deviceInfoSet,
            &deviceInfoData,
            SPDRP_FRIENDLYNAME,
            &nameType,
            reinterpret_cast<PBYTE>(deviceNameBuffer),
            sizeof(deviceNameBuffer),
            nullptr
        )) {

            // Fallback to device description
            SetupDiGetDeviceRegistryPropertyW(
                deviceInfoSet,
                &deviceInfoData,
                SPDRP_DEVICEDESC,
                &nameType,
                reinterpret_cast<PBYTE>(deviceNameBuffer),
                sizeof(deviceNameBuffer),
                nullptr
            );
        }

        deviceNameBuffer[511] = L'\0';

        wstring wideDeviceName(deviceNameBuffer);

        // Convert COM name to string
        string portName(
            widePortName.begin(),
            widePortName.end()
        );

        // Arduino filtering
        if (wideDeviceName.find(L"Arduino") != wstring::npos) {
            portName += " | Arduino";
        }
        // ESP filtering
        else if (wideDeviceName.find(L"ESP") != wstring::npos) {
            portName += " | ESP";
        }
        // STM filtering
        else if (wideDeviceName.find(L"STM") != wstring::npos) {
            portName += " | STM";
        }
        // Standard COM
        else {
            portName += " | Standard COM";
        }

        this->availablePorts.push_back(portName);
    }

    // Release device information list
    SetupDiDestroyDeviceInfoList(deviceInfoSet);

    return this->availablePorts;
}