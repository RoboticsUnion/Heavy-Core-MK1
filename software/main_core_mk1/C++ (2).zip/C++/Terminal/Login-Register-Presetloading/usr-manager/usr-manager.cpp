#include "usr-manager.hpp" 
#include "../../../ansi_color_chart/ansi_color_chart.hpp"

#include "../../../Terminal/Terminal-OUT/Terminal-OUT.hpp"
#include "../../../Terminal/Terminal-IN/Terminal-IN.hpp"

#include <fstream>
#include <iostream>
# include <vector>

#include "../nlohmann/json.hpp"
using json = nlohmann::json;



using namespace std;

void UserManager::startup_terminal(string user_name) {
    terminal_out.terminal_custom_output(UserManager::robotics_union, ansi_color_chart::blue);
    string output = "Loged user: " + user_name;
    terminal_out.terminal_custom_output(output, ansi_color_chart::white);
}

string UserManager::time() {
    time_t now = std::time(nullptr);
    tm* local_time = localtime(&now);
    char buffer[80];

    strftime(buffer, sizeof(buffer), "%d-%m-%Y %H:%M:%S", local_time);

    return string(buffer);
}

void UserManager::register_user(string user_name, string password) {
    ifstream file(db_file);
    json db;

    if (file.is_open()) {
        file >> db;
        file.close();
    } else {
        db = { {"users", json::object()} };
    }

    db["users"][user_name] = {
        {"password", password},
        {"created_at", time()},
        {"presets", { 
            {"standard_l1_lenght", 210},
            {"standard_l2_lenght", 210},
            {"standard_l3_lenght", 210},
            {"standard_l4_lenght", 210},
            {"standard_l5_lenght", 210},
            {"standard_l6_lenght", 210}
    }}
    };

    ofstream out(db_file);
    if (out.is_open()) {
        out << db.dump(4);
        out.close();
    } else {
        string error = terminal_out.terminal_error_output("err_writing_json_login");
        terminal_out.terminal_custom_output(error, ansi_color_chart::red);
    }
}