#include <vector>
#include <string>
#include <iostream>

#include "../Arm-logic/Serial-Data-logic/Serial-comection/serial-conection.hpp"
#include "../ansi_color_chart/ansi_color_chart.hpp"
#include "../Terminal/Terminal-OUT/Terminal-OUT.hpp"
#include "../Terminal/Terminal-IN/Terminal-IN.hpp"


#include "../Terminal/Login-Register-Presetloading/usr-manager/usr-manager.hpp"

#pragma comment(lib, "OneCore.lib")

TerminalOUT terminal_out;
TerminalIN terminal_in;

using namespace std;

int main() {
    UserManager system;
    TerminalIN terminal_in;

    terminal_out.load_error_message("../Terminal/Terminal-OUT/error_list.txt");

    system.startup_terminal("David");

    int num = terminal_in.terminal_read_line_int();

    string user_name = terminal_in.terminal_read_line();
    string user_pas = terminal_in.terminal_read_password();

    system.register_user(user_name, user_pas);

    
}
